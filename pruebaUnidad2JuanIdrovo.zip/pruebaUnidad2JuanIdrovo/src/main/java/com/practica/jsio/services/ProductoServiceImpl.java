package com.practica.jsio.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.practica.jsio.dao.IProductoDao;
import com.practica.jsio.entity.Producto;

@Service
public class ProductoServiceImpl implements IProductoService{

	@Autowired
	IProductoDao productoDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<Producto> findAll() {
	
		return (List<Producto>) productoDao.findAll();
	}

	@Override
	@Transactional
	public Producto save(Producto producto) {
	    
	    double valorCompra = producto.getValorCompra();
	    double descuento = producto.getDescuento();
	    double iva = producto.getIva();
	    double total = producto.getTotal();

	    
	    producto.setValorCompra(valorCompra);
	    producto.setDescuento(descuento);
	    producto.setIva(iva);
	    producto.setTotal(total);

	    return productoDao.save(producto);
	}

	@Override
	@Transactional(readOnly = true)
	public Producto findById(Long codigo) {
		
		return productoDao.findById(codigo).orElse(null);
	}

	@Override
	@Transactional
	public void delete(Long codigo) {
	
		productoDao.deleteById(codigo);
	}
	
	

}
