package com.practica.jsio.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.practica.jsio.entity.Producto;
import com.practica.jsio.services.IProductoService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class ProductoRestController {
	
	@Autowired
	private IProductoService productoService;
	
	@GetMapping("/productos")
	public List<Producto> indext() {
		return productoService.findAll();
	}

	// buscar
	@GetMapping("/productos/{codigo}")
	public Producto show(@PathVariable Long codigo) {
		return productoService.findById(codigo);
	}

	// guardar
	@PostMapping("/productos")
	@ResponseStatus(HttpStatus.CREATED)
	public Producto create(@RequestBody @Valid Producto producto) {
	    return productoService.save(producto);
	}

	// editar
	@PutMapping("/productos/{codigo}")
	@ResponseStatus(HttpStatus.CREATED)
	public Producto update(@RequestBody @Valid Producto producto, @PathVariable Long codigo) {
	    Producto productoActual = productoService.findById(codigo);
	    if (productoActual == null) {
	        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Producto no encontrado");
	    }
	    productoActual.setCantidad(producto.getCantidad());
	    productoActual.setDescripcion(producto.getDescripcion());
	    productoActual.setPrecio(producto.getPrecio());

	    return productoService.save(productoActual);
	}

	// eliminar
	@DeleteMapping("/productos/{codigo}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Long codigo) {
		productoService.delete(codigo);
	}

}
