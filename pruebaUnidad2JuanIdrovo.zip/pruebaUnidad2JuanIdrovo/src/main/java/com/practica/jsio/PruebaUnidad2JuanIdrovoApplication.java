package com.practica.jsio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaUnidad2JuanIdrovoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaUnidad2JuanIdrovoApplication.class, args);
	}

}
