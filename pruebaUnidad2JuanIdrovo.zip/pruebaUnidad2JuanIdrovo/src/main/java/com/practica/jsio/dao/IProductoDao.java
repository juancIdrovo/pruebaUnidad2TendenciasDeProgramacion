package com.practica.jsio.dao;

import org.springframework.data.repository.CrudRepository;

import com.practica.jsio.entity.Producto;

public interface IProductoDao extends CrudRepository<Producto, Long>{

}
