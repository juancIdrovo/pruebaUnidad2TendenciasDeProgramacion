package com.practica.jsio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaUnidad2JuanIdrovoApplicationTests {

	@Test
	void contextLoads() {
	}

}
